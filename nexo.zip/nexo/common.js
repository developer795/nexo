const $=s=>document.querySelector(s);
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('on');clearTimeout(t._h);t._h=setTimeout(()=>t.classList.remove('on'),2200)}
function openM(){$('#modal').classList.add('on');$('#ptxt').focus()}
function closeM(){$('#modal').classList.remove('on')}
function publishPost(){
  const t=$('#ptxt').value.trim();if(!t)return;
  const grid=$('#postGrid'),first=grid.querySelector('.post');
  const card=first.cloneNode(true);
  card.querySelector('p').textContent=t;
  const img=card.querySelector('.img');if(img)img.remove();
  grid.prepend(card);
  if(grid.children.length>3)grid.lastElementChild.remove();
  $('#ptxt').value='';$('#pubBtn').disabled=true;closeM();toast('تم النشر');
}
const ptxt=$('#ptxt');if(ptxt)ptxt.oninput=e=>$('#pubBtn').disabled=!e.target.value.trim();
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#modal'))closeM()});
document.addEventListener('click',e=>{
  const l=e.target.closest('.links a[href="#"]');if(l){e.preventDefault();toast('هذه الميزة خارج الصفحات المطلوبة');return}
  if(e.target.closest('.more,.pen,.soc'))toast('هذه الميزة خارج الصفحات المطلوبة');
  const t=e.target.closest('.post,.opp,.item');
  if(t&&!e.target.closest('button,a'))toast('تفاصيل هذا العنصر في صفحة أخرى');
});
